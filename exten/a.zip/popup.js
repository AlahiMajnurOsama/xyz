// Open ToolsMama extension URLs
function openExtension1() {
  window.open("https://github.com/AlahiMajnurOsama/xyz/raw/refs/heads/main/exten/tm1.zip", "_blank");
}

function openExtension2() {
  window.open("https://github.com/AlahiMajnurOsama/xyz/raw/refs/heads/main/exten/tm2.zip", "_blank");
}