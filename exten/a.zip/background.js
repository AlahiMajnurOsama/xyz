// Fetch credentials with retry logic
async function fetchCredentials(attempt = 1, maxAttempts = 3) {
  const url = "https://raw.githubusercontent.com/AlahiMajnurOsama/xyz/refs/heads/main/exten/cred.json";
  
  try {
    const response = await fetch(url, {
      method: "GET",
      headers: {
        "Content-Type": "application/json",
        // Optional: Use for private repos (uncomment and add your token)
        // "Authorization": "Bearer YOUR_GITHUB_PERSONAL_ACCESS_TOKEN"
      },
      cache: "no-cache"
    });

    if (!response.ok) {
      throw new Error(`HTTP error ${response.status}: ${response.statusText}`);
    }

    const data = await response.json();
    const { username, password } = data[0] || {};

    if (!username || !password) {
      throw new Error("Invalid credentials format in JSON");
    }

    // Store credentials
    await chrome.storage.local.set({ username, password });
    console.log("Credentials fetched and stored successfully");
    return true;

  } catch (error) {
    console.error(`Attempt ${attempt} failed: ${error.message}`);

    // Retry if attempts remain
    if (attempt < maxAttempts) {
      console.log(`Retrying fetch (${attempt + 1}/${maxAttempts})...`);
      await new Promise(resolve => setTimeout(resolve, 1000 * attempt)); // Exponential backoff
      return fetchCredentials(attempt + 1, maxAttempts);
    }

    // Fallback: Use hardcoded credentials (remove in production if not needed)
    console.warn("Using fallback credentials due to fetch failure");
    const fallbackCredentials = {
      username: "alahimajnurosama@gmail.com",
      password: "Ra726ma@#$"
    };
    await chrome.storage.local.set(fallbackCredentials);
    return false;
  }
}

// Run on extension installation
chrome.runtime.onInstalled.addListener(async () => {
  console.log("ToolsMama Helper installed");
  await fetchCredentials();
});

// Run on browser startup
chrome.runtime.onStartup.addListener(async () => {
  await fetchCredentials();
});