// Function to perform login
function performLogin(username, password) {
  if (!username || !password) {
    showError("Credentials not available. Contact your instructor.");
    return;
  }

  // Find login form elements
  const usernameField = document.querySelector("#amember-login");
  const passwordField = document.querySelector("#amember-pass");
  const loginButton = document.querySelector(".frm-submit");

  if (!usernameField || !passwordField || !loginButton) {
    showError("Login fields not found. Contact support.");
    return;
  }

  // Inject credentials with delay to ensure form readiness
  setTimeout(() => {
    usernameField.value = username;
    passwordField.value = password;

    // Show loading feedback
    showFeedback("Logging in...");

    // Submit form
    loginButton.click();

    // Check for login errors (e.g., Recaptcha, validation)
    setTimeout(() => {
      if (window.location.href.includes("app.toolsmama.com/login")) {
        showError("Login failed. Check for Recaptcha or incorrect credentials.");
      } else {
        showFeedback("Login successful!");
      }
    }, 5000);
  }, 500);
}

// Auto-login on page load
window.addEventListener("load", () => {
  if (window.location.href.includes("app.toolsmama.com/login")) {
    chrome.storage.local.get(["username", "password"], (data) => {
      performLogin(data.username, data.password);
    });
  }
});

// Listen for login requests from popup
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.type === "triggerLogin" && window.location.href.includes("app.toolsmama.com/login")) {
    performLogin(message.username, message.password);
    sendResponse({ status: "Login triggered" });
  }
});

// Helper: Show feedback message
function showFeedback(message) {
  const div = document.createElement("div");
  div.style.position = "fixed";
  div.style.top = "10px";
  div.style.right = "10px";
  div.style.padding = "10px";
  div.style.background = "rgba(0, 128, 0, 0.8)";
  div.style.color = "white";
  div.style.borderRadius = "5px";
  div.style.zIndex = "9999";
  div.textContent = message;
  document.body.appendChild(div);
  setTimeout(() => div.remove(), 3000);
}

// Helper: Show error message
function showError(message) {
  const div = document.createElement("div");
  div.style.position = "fixed";
  div.style.top = "10px";
  div.style.right = "10px";
  div.style.padding = "10px";
  div.style.background = "rgba(255, 0, 0, 0.8)";
  div.style.color = "white";
  div.style.borderRadius = "5px";
  div.style.zIndex = "9999";
  div.textContent = message;
  document.body.appendChild(div);
  setTimeout(() => div.remove(), 5000);
}