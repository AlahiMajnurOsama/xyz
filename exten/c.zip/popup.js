// Login to ToolsMama
document.getElementById("login-button").addEventListener("click", async () => {
  const loginButton = document.getElementById("login-button");
  const errorMessage = document.getElementById("error-message");

  // Disable button and show loading state
  loginButton.disabled = true;
  loginButton.classList.add("loading");
  errorMessage.style.display = "none";

  try {
    // Request credentials from background script
    const { username, password } = await new Promise((resolve) => {
      chrome.runtime.sendMessage({ type: "getCredentials" }, (response) => {
        resolve(response);
      });
    });

    if (!username || !password) {
      throw new Error("Credentials not available");
    }

    // Open login page
    const tab = await chrome.tabs.create({ url: "https://app.toolsmama.com/login" });

    // Wait for tab to load and trigger login
    chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: (username, password) => {
        chrome.runtime.sendMessage({
          type: "triggerLogin",
          username,
          password
        });
      },
      args: [username, password]
    });

  } catch (error) {
    errorMessage.textContent = "Failed to login: " + error.message;
    errorMessage.style.display = "block";
  } finally {
    // Re-enable button
    loginButton.disabled = false;
    loginButton.classList.remove("loading");
  }
});

// Open ToolsMama extension URLs
function openExtension1() {
  window.open("https://github.com/AlahiMajnurOsama/xyz/raw/refs/heads/main/exten/tm1.zip", "_blank");
}

function openExtension2() {
  window.open("https://github.com/AlahiMajnurOsama/xyz/raw/refs/heads/main/exten/tm2.zip", "_blank");
}